Legislative Report Router — administrator handoff
Prepared October 28, 2026

READY: STAFF QUEUE IN TEAMS
Upload the inner Legislative-Work-Queue.zip (not this outer handoff ZIP) to the organization's Teams app catalog and make it available to the intended Team/users. It contains manifest.json and both icons. Publishing centrally is an alternative to enabling custom-app uploads for the coordinator.

Existing Entra client ID: 0860a653-ddbd-4455-8bff-affda2a8879f
The deployed staff queue requires only the already-used delegated Sites.ReadWrite.All permission. The Outlook XML manifest remains unchanged. A missing custom-app upload option is governed by Teams policy, not the Outlook manifest.

SEPARATE DESIGN/PERMISSION REVIEW: FULL TWO-WAY CONTACT SYNC
This feature is NOT deployed or enabled. The delegated-only approach is insufficient: Microsoft Graph documents adding a member to an existing tag as application-only.

Proposed requirements for a custom Graph backend:
- Delegated TeamMember.Read.All for current-Team email/identity matching.
- A protected backend service identity with admin-approved APPLICATION TeamworkTag.ReadWrite.All for tag membership additions. Delegated TeamworkTag.ReadWrite alone does not support the required operation.
- Approved backend hosting, server-held identity/credentials, authenticated API access, explicit coordinator authorization and Team/tag allowlists. Backend app registration/API scope details are not finalized, so there is not yet a complete backend deployment manifest.

Alternative for IT: the Microsoft Teams Power Automate connector has AddMemberToTag and DeleteTagMember actions. An approved, authenticated flow may avoid a custom app-only service. Availability, licensing/DLP, connections and the full sync/approval logic need tenant configuration and validation; no flow has been built.

The permission-request.json is for architecture/permission review, NOT a replacement Entra manifest and NOT an instruction to grant application permissions to the browser-only public client. Preserve existing permissions. Do not include a client secret or app-only token in Teams/Outlook scripts or the ZIP.

Keep broad contact rosters separate from coordinator notification tags. The privately preserved prototype compares both sources against the last completed common membership and requires an explicit preview, but it cannot be deployed as full synchronization without the protected service and approved application permission.

No tenant app policy, Entra configuration/consent, real membership or list type was changed during this work. No notifications were sent.

Instructions and primary Microsoft API references:
https://purposebuiltsystems.github.io/legislative-report-router/teams-install.html
https://purposebuiltsystems.github.io/legislative-report-router/docs/contact-sync-admin.md
